﻿Imports Microsoft.VisualStudio.TestTools.UITesting
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks

Namespace FacebookCodedUITestProject
	Public Class SearchSelector
		''' <summary>
		''' Id of the element.
		''' </summary>
		Public Property ID() As String

		''' <summary>
		''' CSS class of the element.
		''' </summary>
		Public Property [Class]() As String

		''' <summary>
		''' HTML Tag name.
		''' </summary>
		Public Property TagName() As String

		Public Function ToPropertyCollection() As PropertyExpressionCollection
			Dim resultCollection = New PropertyExpressionCollection()
			Dim type = GetType(SearchSelector)

			Dim properties = type.GetProperties()

			Dim propertyValue = String.Empty
			For Each [property] In properties
				propertyValue = TryCast([property].GetValue(Me), String)
				If Not String.IsNullOrWhiteSpace(propertyValue) Then
					If propertyValue.Contains("*"c) Then
						propertyValue = propertyValue.Replace("*", String.Empty)
						resultCollection.Add([property].Name, propertyValue, PropertyExpressionOperator.Contains)
					Else
						resultCollection.Add([property].Name, propertyValue, PropertyExpressionOperator.EqualTo)
					End If
				End If
			Next [property]

			Return resultCollection
		End Function

		''' <summary>
		''' Returns a string with all selector filters.
		''' </summary>
		''' <returns>String with all filters description.</returns>
		Public Overrides Function ToString() As String
			Dim stringBuilder As New StringBuilder()
			Dim criteria = Me.ToPropertyCollection()

			For Each searchParameter In criteria
				stringBuilder.AppendFormat("Name:{0}    Value:{1}.{2}", searchParameter.PropertyName, searchParameter.PropertyValue, Environment.NewLine)
			Next searchParameter

			Return stringBuilder.ToString()
		End Function
	End Class
End Namespace
