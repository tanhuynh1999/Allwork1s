﻿Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks

Namespace FacebookCodedUITestProject
	''' <summary>
	''' Determines browser type.
	''' </summary>
	Public Enum Browser
		IE
		Chrome
		Firefox
		Opera
	End Enum
End Namespace
