﻿Imports Microsoft.VisualStudio.TestTools.UITesting.HtmlControls
Imports Microsoft.VisualStudio.TestTools.UITest.Extension
Imports System.Threading.Tasks
Imports System.Text
Imports System.Linq
Imports Microsoft.VisualStudio.TestTools.UITesting


Namespace FacebookCodedUITestProject.Pages

	Public MustInherit Class BasePage
		Inherits UITestControl
		Protected Const BaseURL As String = "https://www.facebook.com/"

		''' <summary>
		''' Gets URL address of the current page.
		''' </summary>
		Private privatePageUrl As Uri
		Public Property PageUrl() As Uri
			Get
				Return privatePageUrl
			End Get
			Protected Set(ByVal value As Uri)
				privatePageUrl = value
			End Set
		End Property

		''' <summary>
		''' Store the root control for the page.
		''' </summary>
		Protected Body As UITestControl

		''' <summary>
		''' Current broser window.
		''' </summary>
		Protected Property BrowserWindow() As BrowserWindow

		''' <summary>
		''' Default constructor.
		''' </summary>
		Public Sub New()
			Me.ConstructUrl()
		End Sub

		''' <summary>
		''' Navigate to the specyfic URL by using current browser window.
		''' </summary>
		''' <typeparam name="T">Type of the page.</typeparam>
		''' <returns>Created page object.</returns>
		Public Function NavigateTo(Of T As {BasePage, New})() As T
			If Me.BrowserWindow Is Nothing Then
				Throw New InvalidOperationException("BrowserWindow is null. Use Lunch to initialize browser.")
			End If

			Dim page As New T()
			Dim url = page.ConstructUrl()

			Me.BrowserWindow.NavigateToUrl(url)
			Me.BrowserWindow.WaitForControlReady()

			page.Body = TryCast((TryCast(Me.BrowserWindow.CurrentDocumentWindow.GetChildren()(0), UITestControl)), HtmlControl)

			Return page
		End Function

		''' <summary>
		''' Initialize page from current browser window.
		''' </summary>
		''' <typeparam name="T">Type of the page.</typeparam>
		''' <returns>Created page object.</returns>
		Public Function InitializePage(Of T As {BasePage, New})() As T
			If Me.BrowserWindow Is Nothing Then
				Throw New InvalidOperationException("BrowserWindow is null. Use Lunch to initialize browser.")
			End If

			Dim page As New T()
			page.BrowserWindow = Me.BrowserWindow
			page.Body = TryCast((TryCast(Me.BrowserWindow.CurrentDocumentWindow.GetChildren()(0), UITestControl)), HtmlControl)
			Return page
		End Function

		''' <summary>
		''' Builds derived page URL based on the BaseURL and specyfic page URL.
		''' </summary>
		''' <returns></returns>
		Protected MustOverride Function ConstructUrl() As Uri

		''' <summary>
		''' Veryfies derived page is displayed correctly.
		''' </summary>
		''' <returns></returns>
		Public MustOverride Function IsValidPageDisplayed() As Boolean

		''' <summary>
		''' 
		''' </summary>
		''' <typeparam name="T">Type of the page to open.</typeparam>
		''' <param name="browser"></param>
		''' <param name="clearCookies"></param>
		''' <param name="maximized"></param>
		''' <returns>New page instance.</returns>
		''' <remarks>Requires to install http://visualstudiogallery.msdn.microsoft.com/11cfc881-f8c9-4f96-b303-a2780156628d .</remarks>
		Public Shared Function Launch(Of T As {BasePage, New})(Optional ByVal browser As Browser = Browser.IE, Optional ByVal clearCookies As Boolean = True, Optional ByVal maximized As Boolean = True) As T
			Dim page As New T()

			Dim url = page.PageUrl
			If url Is Nothing Then
				Throw New InvalidOperationException("Unable to find URL for requested page.")
			End If

			Dim pathToBrowserExe = FacebookCodedUITestProject.BrowserFactory.GetBrowserExePath(browser)

			' Setting the currect frowser fot the test.
			BrowserWindow.CurrentBrowser = "ie"
			Dim window = BrowserWindow.Launch(page.ConstructUrl())
			page.BrowserWindow = window

			If window Is Nothing Then
				Dim errorMessage = String.Format("Unable to run browser under the path: {0}", pathToBrowserExe)
				Throw New InvalidOperationException(errorMessage)
			End If

			page.Body = TryCast((TryCast(window.CurrentDocumentWindow.GetChildren()(0), UITestControl)), HtmlControl)

			If clearCookies Then
				BrowserWindow.ClearCookies()
			End If

			window.Maximized = maximized

			If Not page.IsValidPageDisplayed() Then
				Throw New InvalidOperationException("Invalid page is displayed.")
			End If

			Return page
		End Function
	End Class
End Namespace
