﻿Imports Microsoft.VisualStudio.TestTools.UITesting.HtmlControls
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks

Namespace FacebookCodedUITestProject.Pages
	''' <summary>
	''' Represent a profile page.
	''' </summary>
	Public Class ProfilePage
		Inherits BasePage
		''' <summary>
		''' Id of the link to the profile.
		''' </summary>
		Private Const ProfileLinkClassName As String= "fbxWelcomeBoxName"

		''' <summary>
		''' Id of the div which contains upload controls.
		''' </summary>
		Private Const UploadDivId As String = "pagelet_composer"

		''' <summary>
		''' Construct a login URL.
		''' </summary>
		''' <returns>A login page URL.</returns>
		Protected Overrides Function ConstructUrl() As Uri
			Return New Uri(BasePage.BaseURL)
		End Function

		''' <summary>
		''' Validating Profile page is visible.
		''' </summary>
		''' <returns></returns>
		Public Overrides Function IsValidPageDisplayed() As Boolean
			Dim profilLink = Me.Body.FindFirstByCssClass(Of HtmlHyperlink)(ProfileLinkClassName)
			Dim uploadingDiv = Me.Body.FindById(Of HtmlDiv)(UploadDivId)
			Return profilLink IsNot Nothing AndAlso uploadingDiv IsNot Nothing
		End Function
	End Class
End Namespace
