﻿Imports System.Text.RegularExpressions
Imports System.Windows.Input
Imports Microsoft.VisualStudio.TestTools.UITesting
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Microsoft.VisualStudio.TestTools.UITest.Extension
Imports Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard
Imports Microsoft.VisualStudio.TestTools.UITesting.HtmlControls
Imports Microsoft.VisualStudio.TestTools.UITest.Common.UIMap
Imports System.Linq
Imports FacebookCodedUITestProject.Pages

Namespace FacebookCodedUITestProject
	''' <summary>
	''' Summary description for CodedUITest1
	''' </summary>
	<CodedUITest>
	Public Class FacebookUITests
		Private Const fbLogin As String = "wirtual11@gmail.com"
		Private Const fbPassword As String = "valid_pwd"

		Private testContextInstance As TestContext

		''' <summary>
		'''Gets or sets the test context which provides
		'''information about and functionality for the current test run.
		'''</summary>
		Public Property TestContext() As TestContext
			Get
				Return testContextInstance
			End Get
			Set(ByVal value As TestContext)
				testContextInstance = value
			End Set
		End Property

		''' <summary>
		''' Testing for invalid login.
		''' </summary>
		<TestMethod>
		Public Sub FacebookValidLogin()
			Dim loginPage = BasePage.Launch(Of LoginPage)()
			loginPage.TypeCredentailAndClickLogin(fbLogin, fbPassword)

			Dim profilePage = loginPage.InitializePage(Of ProfilePage)()
			Assert.IsTrue(profilePage.IsValidPageDisplayed(), "Profile page is not displayed.")
		End Sub

		''' <summary>
		''' Testing for valid login.
		''' </summary>
		Public Sub FacebookInvalidLogin()
			Dim invalidData = Guid.NewGuid().ToString()
			Dim loginPanel = BasePage.Launch(Of LoginPage)()
			loginPanel.TypeCredentailAndClickLogin(invalidData, invalidData)
			Dim errorDialog = loginPanel.ErrorDialog
			Assert.IsNotNull(errorDialog, "Error dialog is not visible.")
		End Sub

        <TestCleanup>
        Public Sub TestCleanup()
            Dim outCome As Object = Me.testContextInstance.CurrentTestOutcome

            If outCome IsNot Nothing AndAlso Me.TestContext.CurrentTestOutcome.ToString() = "Failed" Then
                Try
                    Dim img = BrowserWindow.Desktop.CaptureImage()
                    Dim pathToSave = System.IO.Path.Combine(Me.TestContext.TestResultsDirectory, String.Format("{0}.jpg", Me.TestContext.TestName))
                    Dim bitmap = New Bitmap(img)
                    bitmap.Save(pathToSave)
                Catch
                    Me.TestContext.WriteLine("Unable to capture or save screen.")
                End Try
            End If
        End Sub
	End Class
End Namespace