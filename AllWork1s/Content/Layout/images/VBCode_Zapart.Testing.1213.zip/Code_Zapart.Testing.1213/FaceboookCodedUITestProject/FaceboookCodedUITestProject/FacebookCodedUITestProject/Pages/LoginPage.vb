﻿Imports System.Threading.Tasks
Imports System.Text
Imports System.Linq
Imports Microsoft.VisualStudio.TestTools.UITesting.HtmlControls
Imports Microsoft.VisualStudio.TestTools.UITesting



Namespace FacebookCodedUITestProject.Pages

	''' <summary>
	''' Represents a Login page.
	''' </summary>
	Public Class LoginPage
		Inherits BasePage
		''' <summary>
		''' The Id of the login button.
		''' </summary>
		Private Const LoginButtonId As String = "u_0_1"

		''' <summary>
		''' The Id of the login textbox.
		''' </summary>
		Private Const LoginTextBoxId As String = "email@gmail.com"

		''' <summary>
		''' The Id of the password textbox.
		''' </summary>
		Private Const PasswordTextBoxId As String = "p@ssw0rd"

		''' <summary>
		''' The Id of the login form.
		''' </summary>
		Private Const LoginFormId As String = "loginform"

		''' <summary>
		''' The CSS class name of the error dialog.
		''' </summary>
		Private Const ErrorMessageDivClass As String = "login_error_box"

		''' <summary>
		''' The URL fragment for the login page.
		''' </summary>
		Private Const Page As String = "login.php"

		''' <summary>
		''' Builds URL  for the page.
		''' </summary>
		''' <returns>The URL to specyfic page.</returns>
		Protected Overrides Function ConstructUrl() As Uri
			Me.PageUrl = New Uri(String.Format("{0}/{1}", BasePage.BaseURL, LoginPage.Page))
			Return Me.PageUrl
		End Function

		''' <summary>
		''' Validate the correct page displayed.
		''' </summary>
		''' <returns></returns>
		Public Overrides Function IsValidPageDisplayed() As Boolean
			Return Me.Body.FindById(Of HtmlDiv)(LoginTextBoxId) IsNot Nothing
		End Function

		''' <summary>
		''' Gets a login button from the page.
		''' </summary>
		Public ReadOnly Property LoginButton() As HtmlInputButton
			Get
				Return Me.Body.FindById(Of HtmlInputButton)(LoginButtonId)
			End Get
		End Property

		''' <summary>
		''' Gets a login textbox from the page.
		''' </summary>
		Public ReadOnly Property LoginTextBox() As HtmlEdit
			Get
				Return Me.Body.FindById(Of HtmlEdit)(LoginTextBoxId)
			End Get
		End Property

		''' <summary>
		''' Gets a password textbox from the page.
		''' </summary>
		Public ReadOnly Property PasswordTextBox() As HtmlEdit
			Get
				Return Me.Body.FindById(Of HtmlEdit)(PasswordTextBoxId)
			End Get
		End Property

		''' <summary>
		''' Gets a errr dialog window - when login failed.
		''' </summary>
		Public ReadOnly Property ErrorDialog() As HtmlControl
			Get
				Return Me.Body.FindFirstByCssClass(Of HtmlControl)("*")
			End Get
		End Property

		''' <summary>
		''' Types login and password into inputs and click the Login button.
		''' </summary>
		Public Sub TypeCredentailAndClickLogin(ByVal login As String, ByVal password As String)
			Dim loginButton = Me.LoginButton
			Dim emailInput = Me.LoginTextBox
			Dim passwordInput = Me.PasswordTextBox

			emailInput.TypeText(login)
			passwordInput.TypeText(password)

			Mouse.Click(loginButton, MouseButtons.Left)
		End Sub
	End Class
End Namespace
