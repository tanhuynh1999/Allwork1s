﻿Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks

Namespace FacebookCodedUITestProject
	''' <summary>
	''' Class to manage browser to run tests against.
	''' </summary>
	Public Class BrowserFactory
		''' <summary>
		''' Resolving a browser exe path based on the Setting.
		''' </summary>
		''' <param name="browser"><see cref="Broser"/> type.</param>
		''' <returns>Path to the exe for specific browser.</returns>
		Public Shared Function GetBrowserExePath(ByVal browser As Browser) As String
			Dim path = String.Empty
			Dim settings = My.Settings.Default

			Select Case browser
				Case Browser.IE
					path = settings.IeExePath
				Case Browser.Chrome
					path = settings.ChromeExePath
				Case Browser.Firefox
					path = settings.FirefoxExePath
				Case Browser.Opera
					path = settings.OperaExePath
				Case Else
					path = settings.IeExePath
			End Select

			If String.IsNullOrWhiteSpace(path) Then
				Throw New InvalidOperationException(String.Format("Path to the browser exe for {0} can not be empty.", browser.ToString()))
			End If

			Return path
		End Function
	End Class
End Namespace
