﻿Imports Microsoft.VisualStudio.TestTools.UITesting
Imports Microsoft.VisualStudio.TestTools.UITesting.HtmlControls
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports System.Collections.ObjectModel
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Automation

Namespace FacebookCodedUITestProject
	Public Module UIControllExtensions
		<System.Runtime.CompilerServices.Extension> _
		Public Function FindById(Of T As {HtmlControl, New})(ByVal control As UITestControl, ByVal controlId As String) As T
			Dim allResult = FindAll(Of T)(control, New SearchSelector() With {.ID = controlId})
			Dim resultControl As T = Nothing

			If allResult.Any() Then
				resultControl = allResult(0)
			End If

			Return resultControl
		End Function

		''' <summary>
		''' Search HTML control by class name.
		''' </summary>
		''' <typeparam name="T">Type of the element to find.</typeparam>
		''' <param name="control">Control to extend.</param>
		''' <param name="className">Class name fo find.</param>
		''' <param name="contains">Determines control contains only one class with given name or given class name is part of css classes for control.</param>
		''' <returns></returns>
		<System.Runtime.CompilerServices.Extension> _
		Public Function FindFirstByCssClass(Of T As {HtmlControl, New})(ByVal control As UITestControl, ByVal className As String, Optional ByVal contains As Boolean = True) As T
			If contains Then
				className = String.Format("*{0}", className)
			End If

			Dim allResult = FindAll(Of T)(control, New SearchSelector() With {.Class = className})
			Dim resultControl As T = Nothing

			If allResult.Any() Then
				resultControl = allResult(0)
			End If

			Return resultControl
		End Function

		''' <summary>
		''' Set focus to the HTML input control and type all characters from passed string one by one.
		''' </summary>
		''' <param name="inputControl">Input to type text on.</param>
		''' <param name="text">Text to be typed to the control.</param>
		''' <param name="append">Determines control will be cleaned before start typing.</param>
		<System.Runtime.CompilerServices.Extension> _
		Public Sub TypeText(ByVal inputControl As HtmlEdit, ByVal text As String, Optional ByVal append As Boolean = False)
			If inputControl Is Nothing Then
				Throw New ArgumentNullException("inputControl")
			End If

			If String.IsNullOrWhiteSpace(text) Then
				Throw New ArgumentNullException("text")
			End If

			inputControl.SetFocus()

			Assert.IsTrue((Not inputControl.ReadOnly) AndAlso inputControl.Enabled, "Control is disabled or read-only.")

			If Not append Then
				inputControl.Text = String.Empty
			End If

			inputControl.Text = text
		End Sub

		<System.Runtime.CompilerServices.Extension> _
		Private Function FindAll(Of T As {HtmlControl, New})(ByVal control As UITestControl, ByVal selectorDefinition As SearchSelector) As ReadOnlyCollection(Of T)
			Dim result = New List(Of T)()
			Dim selectorElement As T = New T With {.Container = control}
			selectorElement.SearchProperties.AddRange(selectorDefinition.ToPropertyCollection())

			If Not selectorElement.Exists Then
				Trace.WriteLine(String.Format("Html {0} element not exists for given selector {1}.", GetType(T).Name, selectorDefinition), "UI CodedTest")
				Return result.AsReadOnly()
			End If

			Return selectorElement.FindMatchingControls().Select(Function(c) CType(c, T)).ToList().AsReadOnly()
		End Function
	End Module
End Namespace
