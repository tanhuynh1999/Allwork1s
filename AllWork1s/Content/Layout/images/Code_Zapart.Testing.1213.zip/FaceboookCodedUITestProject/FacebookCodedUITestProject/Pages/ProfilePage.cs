﻿using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FacebookCodedUITestProject.Pages
{
    /// <summary>
    /// Represent a profile page.
    /// </summary>
    public class ProfilePage : BasePage
    {
        /// <summary>
        /// Id of the link to the profile.
        /// </summary>
        private const string ProfileLinkClassName= "fbxWelcomeBoxName";

        /// <summary>
        /// Id of the div which contains upload controls.
        /// </summary>
        private const string UploadDivId = "pagelet_composer";

        /// <summary>
        /// Construct a login URL.
        /// </summary>
        /// <returns>A login page URL.</returns>
        protected override Uri ConstructUrl()
        {
            return new Uri(BasePage.BaseURL);
        }

        /// <summary>
        /// Validating Profile page is visible.
        /// </summary>
        /// <returns></returns>
        public override bool IsValidPageDisplayed()
        {
            var profilLink = this.Body.FindFirstByCssClass<HtmlHyperlink>(ProfileLinkClassName);
            var uploadingDiv = this.Body.FindById<HtmlDiv>(UploadDivId);
            return profilLink != null && uploadingDiv != null;
        }
    }
}
