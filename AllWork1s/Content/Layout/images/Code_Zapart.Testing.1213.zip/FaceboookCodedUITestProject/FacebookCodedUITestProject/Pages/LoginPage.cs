﻿

namespace FacebookCodedUITestProject.Pages
{
    using Microsoft.VisualStudio.TestTools.UITesting;
    using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Represents a Login page.
    /// </summary>
    public class LoginPage : BasePage
    {
        /// <summary>
        /// The Id of the login button.
        /// </summary>
        private const string LoginButtonId = "u_0_1";

        /// <summary>
        /// The Id of the login textbox.
        /// </summary>
        private const string LoginTextBoxId = "email@gmail.com";

        /// <summary>
        /// The Id of the password textbox.
        /// </summary>
        private const string PasswordTextBoxId = "p@ssw0rd";

        /// <summary>
        /// The Id of the login form.
        /// </summary>
        private const string LoginFormId = "loginform";

        /// <summary>
        /// The CSS class name of the error dialog.
        /// </summary>
        private const string ErrorMessageDivClass = "login_error_box";

        /// <summary>
        /// The URL fragment for the login page.
        /// </summary>
        private const string Page = "login.php";

        /// <summary>
        /// Builds URL  for the page.
        /// </summary>
        /// <returns>The URL to specyfic page.</returns>
        protected override Uri ConstructUrl()
        {
            this.PageUrl = new Uri(string.Format("{0}/{1}", BasePage.BaseURL, LoginPage.Page));
            return this.PageUrl;
        }

        /// <summary>
        /// Validate the correct page displayed.
        /// </summary>
        /// <returns></returns>
        public override bool IsValidPageDisplayed()
        {
            return this.Body.FindById<HtmlDiv>(LoginTextBoxId) != null;
        }

        /// <summary>
        /// Gets a login button from the page.
        /// </summary>
        public HtmlInputButton LoginButton
        {
            get
            {
                return this.Body.FindById<HtmlInputButton>(LoginButtonId);
            }
        }

        /// <summary>
        /// Gets a login textbox from the page.
        /// </summary>
        public HtmlEdit LoginTextBox
        {
            get
            {
                return this.Body.FindById<HtmlEdit>(LoginTextBoxId);
            }
        }

        /// <summary>
        /// Gets a password textbox from the page.
        /// </summary>
        public HtmlEdit PasswordTextBox
        {
            get
            {
                return this.Body.FindById<HtmlEdit>(PasswordTextBoxId);
            }
        }

        /// <summary>
        /// Gets a errr dialog window - when login failed.
        /// </summary>
        public HtmlControl ErrorDialog
        {
            get
            {
                return this.Body.FindFirstByCssClass<HtmlControl>("*");
            }
        }

        /// <summary>
        /// Types login and password into inputs and click the Login button.
        /// </summary>
        public void TypeCredentailAndClickLogin(string login, string password)
        {
            var loginButton = this.LoginButton;
            var emailInput = this.LoginTextBox;
            var passwordInput = this.PasswordTextBox;

            emailInput.TypeText(login);
            passwordInput.TypeText(password);

            Mouse.Click(loginButton, System.Windows.Forms.MouseButtons.Left);
        }
    }
}
