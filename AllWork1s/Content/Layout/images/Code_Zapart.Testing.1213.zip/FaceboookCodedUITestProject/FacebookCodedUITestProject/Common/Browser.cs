﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FacebookCodedUITestProject
{
    /// <summary>
    /// Determines browser type.
    /// </summary>
    public enum Browser
    {
        IE,
        Chrome,
        Firefox,
        Opera
    }
}
