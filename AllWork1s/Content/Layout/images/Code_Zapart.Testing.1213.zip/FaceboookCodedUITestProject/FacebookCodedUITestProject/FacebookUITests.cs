﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Input;
using System.Windows.Forms;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UITest.Extension;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITest.Common.UIMap;
using System.Linq;
using FacebookCodedUITestProject.Pages;

namespace FacebookCodedUITestProject
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]
    public class FacebookUITests
    {
        private const string fbLogin = "wirtual11@gmail.com";
        private const string fbPassword = "valid_pwd";

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        /// <summary>
        /// Testing for invalid login.
        /// </summary>
        [TestMethod]
        public void FacebookValidLogin()
        {
            var loginPage = BasePage.Launch<LoginPage>();
            loginPage.TypeCredentailAndClickLogin(fbLogin, fbPassword);

            var profilePage = loginPage.InitializePage<ProfilePage>();
            Assert.IsTrue(profilePage.IsValidPageDisplayed(), "Profile page is not displayed.");
        }

        /// <summary>
        /// Testing for valid login.
        /// </summary>
        public void FacebookInvalidLogin()
        {
            var invalidData = Guid.NewGuid().ToString();
            var loginPanel = BasePage.Launch<LoginPage>();
            loginPanel.TypeCredentailAndClickLogin(invalidData, invalidData);
            var errorDialog = loginPanel.ErrorDialog;
            Assert.IsNotNull(errorDialog, "Error dialog is not visible.");
        }

        [TestCleanup]
        public void TestCleanup()
        {
            if (this.TestContext.CurrentTestOutcome != null && this.TestContext.CurrentTestOutcome.ToString() == "Failed")
            {
                try
                {
                    var img = BrowserWindow.Desktop.CaptureImage();
                    var pathToSave = System.IO.Path.Combine(this.TestContext.TestResultsDirectory, string.Format("{0}.jpg", this.TestContext.TestName));
                    var bitmap = new Bitmap(img);
                    bitmap.Save(pathToSave);
                }
                catch
                {
                    this.TestContext.WriteLine("Unable to capture or save screen.");
                }
            }
        }
    }
}